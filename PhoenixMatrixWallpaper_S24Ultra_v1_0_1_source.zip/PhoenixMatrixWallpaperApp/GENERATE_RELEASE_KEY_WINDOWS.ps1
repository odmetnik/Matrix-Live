$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$key = Join-Path $here "phoenix-release.jks"
if (Test-Path $key) {
  Write-Host "Keystore already exists: $key"
  exit 0
}
Write-Host "Creating Phoenix Art release keystore. Keep this file and its passwords safe; future updates must use the same key."
& keytool -genkeypair -v -keystore $key -alias phoenix -keyalg RSA -keysize 4096 -validity 10000
Write-Host "Created: $key"
