param(
  [string]$Gradle = "gradle"
)
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$key = Join-Path $here "phoenix-release.jks"
if (!(Test-Path $key)) {
  throw "Missing phoenix-release.jks. Run GENERATE_RELEASE_KEY_WINDOWS.ps1 first."
}
$store = Read-Host "Keystore password" -AsSecureString
$keypass = Read-Host "Key password" -AsSecureString
function Plain([Security.SecureString]$s) {
  $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($s)
  try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
}
$env:PHOENIX_KEYSTORE = $key
$env:PHOENIX_STORE_PASSWORD = Plain $store
$env:PHOENIX_KEY_ALIAS = "phoenix"
$env:PHOENIX_KEY_PASSWORD = Plain $keypass
Push-Location $here
try {
  & $Gradle :app:assembleRelease
  Write-Host "APK: app\build\outputs\apk\release\app-release.apk"
} finally {
  Pop-Location
  Remove-Item Env:PHOENIX_STORE_PASSWORD -ErrorAction SilentlyContinue
  Remove-Item Env:PHOENIX_KEY_PASSWORD -ErrorAction SilentlyContinue
}
