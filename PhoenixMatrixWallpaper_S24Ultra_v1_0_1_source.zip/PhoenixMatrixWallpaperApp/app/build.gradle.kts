plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val releaseKeystore = System.getenv("PHOENIX_KEYSTORE")
val releaseStorePassword = System.getenv("PHOENIX_STORE_PASSWORD")
val releaseKeyAlias = System.getenv("PHOENIX_KEY_ALIAS")
val releaseKeyPassword = System.getenv("PHOENIX_KEY_PASSWORD")

android {
    namespace = "hr.phoenixart.matrixwallpaper"
    compileSdk = 34

    defaultConfig {
        applicationId = "hr.phoenixart.matrixwallpaper"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "1.0.2"
    }

    signingConfigs {
        if (!releaseKeystore.isNullOrBlank() &&
            !releaseStorePassword.isNullOrBlank() &&
            !releaseKeyAlias.isNullOrBlank() &&
            !releaseKeyPassword.isNullOrBlank()) {
            create("release") {
                storeFile = file(releaseKeystore)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.findByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { viewBinding = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
