package hr.phoenixart.matrixwallpaper

import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View

class MatrixPreviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs), Choreographer.FrameCallback {

    private val renderer = MatrixRenderer()
    private var running = false
    private var lastNanos = 0L
    private var frameDt = 1f / 30f
    private var drawScale = 1f

    var settings: Prefs.Settings
        get() = renderer.settings
        set(value) {
            renderer.settings = value
            invalidate()
        }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // Keep the preview to ~42% of the screen height so the sliders stay visible next to it.
        val availW = MeasureSpec.getSize(widthMeasureSpec).coerceAtLeast(1)
        val maxH = (resources.displayMetrics.heightPixels * 0.42f).toInt().coerceAtLeast(1)
        var w = availW
        var h = (w * (19.5f / 9f)).toInt()
        if (h > maxH) {
            h = maxH
            w = (h * (9f / 19.5f)).toInt().coerceAtLeast(1)
        }
        setMeasuredDimension(w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        // Render at real screen width and scale down, so the miniature matches the actual wallpaper.
        val dm = resources.displayMetrics
        val virtW = dm.widthPixels.coerceAtLeast(1)
        drawScale = w.coerceAtLeast(1) / virtW.toFloat()
        val virtH = (h / drawScale).toInt().coerceAtLeast(1)
        renderer.resize(virtW, virtH, dm.density)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.save()
        canvas.scale(drawScale, drawScale)
        renderer.render(canvas, frameDt, System.currentTimeMillis())
        canvas.restore()
    }

    fun start() {
        if (running) return
        running = true
        lastNanos = 0L
        Choreographer.getInstance().postFrameCallback(this)
    }

    fun stop() {
        running = false
        Choreographer.getInstance().removeFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        frameDt = if (lastNanos == 0L) 1f / 30f
        else ((frameTimeNanos - lastNanos) / 1_000_000_000f).coerceIn(0f, .05f)
        lastNanos = frameTimeNanos
        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                renderer.offsetX = ((event.x / width.coerceAtLeast(1)) - .5f).coerceIn(-.5f, .5f)
                renderer.offsetY = ((event.y / height.coerceAtLeast(1)) - .5f).coerceIn(-.5f, .5f)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                renderer.offsetX = 0f
                renderer.offsetY = 0f
                invalidate()
            }
        }
        return true
    }
}
