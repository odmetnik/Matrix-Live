package hr.phoenixart.matrixwallpaper

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import hr.phoenixart.matrixwallpaper.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var settings = Prefs.Settings()
    private var bindingUi = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settings = Prefs.load(this)
        setupQualitySpinner()
        bindActions()
        bindValues()
    }

    override fun onResume() {
        super.onResume()
        binding.preview.settings = settings
        binding.preview.start()
    }

    override fun onPause() {
        binding.preview.stop()
        super.onPause()
    }

    private fun setupQualitySpinner() {
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.quality_entries,
            android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerQuality.adapter = adapter
    }

    private fun bindValues() = with(binding) {
        bindingUi = true
        seekSpeed.progress = Prefs.valueToProgress(settings.speed, 0.2f, 2.2f)
        seekDepth.progress = Prefs.valueToProgress(settings.depth, 0.2f, 2.2f)
        seekLogo.progress = Prefs.valueToProgress(settings.logo, 0.2f, 2.2f)
        seekGlow.progress = Prefs.valueToProgress(settings.glow, 0.2f, 2.2f)
        seekDensity.progress = Prefs.valueToProgress(settings.density, 0.55f, 1.45f)
        seekRain.progress = Prefs.valueToProgress(settings.rain, 0.4f, 2.2f)
        seekVertical.progress = Prefs.valueToProgress(settings.vertical, -0.16f, 0.16f)
        seekTint.progress = Prefs.valueToProgress(settings.tint, -0.30f, 0.30f)
        spinnerQuality.setSelection(settings.quality.coerceIn(0, 2), false)
        preview.settings = settings
        updateLabels()
        bindingUi = false
    }

    private fun bindActions() = with(binding) {
        bindSeek(seekSpeed) { settings = settings.copy(speed = Prefs.progressToValue(it, 0.2f, 2.2f)); save() }
        bindSeek(seekDepth) { settings = settings.copy(depth = Prefs.progressToValue(it, 0.2f, 2.2f)); save() }
        bindSeek(seekLogo) { settings = settings.copy(logo = Prefs.progressToValue(it, 0.2f, 2.2f)); save() }
        bindSeek(seekGlow) { settings = settings.copy(glow = Prefs.progressToValue(it, 0.2f, 2.2f)); save() }
        bindSeek(seekDensity) { settings = settings.copy(density = Prefs.progressToValue(it, 0.55f, 1.45f)); save() }
        bindSeek(seekRain) { settings = settings.copy(rain = Prefs.progressToValue(it, 0.4f, 2.2f)); save() }
        bindSeek(seekVertical) { settings = settings.copy(vertical = Prefs.progressToValue(it, -0.16f, 0.16f)); save() }
        bindSeek(seekTint) { settings = settings.copy(tint = Prefs.progressToValue(it, -0.30f, 0.30f)); save() }

        spinnerQuality.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                if (bindingUi) return
                settings = settings.copy(quality = position.coerceIn(0, 2))
                save()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        btnReset.setOnClickListener {
            settings = Prefs.Settings()
            Prefs.save(this@MainActivity, settings)
            bindValues()
        }

        btnSetWallpaper.setOnClickListener { openWallpaperPreview() }
    }

    private fun bindSeek(seekBar: SeekBar, onChanged: (Int) -> Unit) {
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser || bindingUi) return
                onChanged(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

    private fun save() {
        Prefs.save(this, settings)
        binding.preview.settings = settings
        updateLabels()
    }

    private fun updateLabels() = with(binding) {
        tvSpeed.text = getString(R.string.speed_value, settings.speed)
        tvDepth.text = getString(R.string.depth_value, settings.depth)
        tvLogo.text = getString(R.string.logo_value, settings.logo)
        tvGlow.text = getString(R.string.glow_value, settings.glow)
        tvDensity.text = getString(R.string.density_value, settings.density)
        tvRain.text = getString(R.string.rain_value, settings.rain)
        tvVertical.text = getString(R.string.vertical_value, (settings.vertical * 100f).toInt())
        tvTint.text = getString(R.string.tint_value, settings.tint)
    }

    private fun openWallpaperPreview() {
        val component = ComponentName(this, MatrixWallpaperService::class.java)
        try {
            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
            }
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }
}
