package hr.phoenixart.matrixwallpaper

import android.content.Context
import androidx.core.content.edit
import kotlin.math.roundToInt

object Prefs {
    const val PREF_NAME = "phoenix_matrix_wallpaper"
    private const val KEY_SPEED = "speed"
    private const val KEY_DEPTH = "depth"
    private const val KEY_LOGO = "logo"
    private const val KEY_GLOW = "glow"
    private const val KEY_TINT = "tint"
    private const val KEY_DENSITY = "density"
    private const val KEY_VERTICAL = "vertical"
    private const val KEY_QUALITY = "quality"
    private const val KEY_RAIN = "rain"

    const val DEFAULT_SPEED = 1.0f
    const val DEFAULT_DEPTH = 1.0f
    const val DEFAULT_LOGO = 1.25f
    const val DEFAULT_GLOW = 1.15f
    const val DEFAULT_TINT = 0f
    const val DEFAULT_DENSITY = 1.0f
    const val DEFAULT_VERTICAL = 0f
    const val DEFAULT_QUALITY = 1
    const val DEFAULT_RAIN = 1.0f

    data class Settings(
        val speed: Float = DEFAULT_SPEED,
        val depth: Float = DEFAULT_DEPTH,
        val logo: Float = DEFAULT_LOGO,
        val glow: Float = DEFAULT_GLOW,
        val tint: Float = DEFAULT_TINT,
        val density: Float = DEFAULT_DENSITY,
        val vertical: Float = DEFAULT_VERTICAL,
        val quality: Int = DEFAULT_QUALITY,
        val rain: Float = DEFAULT_RAIN
    )

    fun load(context: Context): Settings {
        val p = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return Settings(
            speed = p.getFloat(KEY_SPEED, DEFAULT_SPEED),
            depth = p.getFloat(KEY_DEPTH, DEFAULT_DEPTH),
            logo = p.getFloat(KEY_LOGO, DEFAULT_LOGO),
            glow = p.getFloat(KEY_GLOW, DEFAULT_GLOW),
            tint = p.getFloat(KEY_TINT, DEFAULT_TINT),
            density = p.getFloat(KEY_DENSITY, DEFAULT_DENSITY),
            vertical = p.getFloat(KEY_VERTICAL, DEFAULT_VERTICAL),
            quality = p.getInt(KEY_QUALITY, DEFAULT_QUALITY),
            rain = p.getFloat(KEY_RAIN, DEFAULT_RAIN)
        )
    }

    fun save(context: Context, s: Settings) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit {
            putFloat(KEY_SPEED, s.speed)
            putFloat(KEY_DEPTH, s.depth)
            putFloat(KEY_LOGO, s.logo)
            putFloat(KEY_GLOW, s.glow)
            putFloat(KEY_TINT, s.tint)
            putFloat(KEY_DENSITY, s.density)
            putFloat(KEY_VERTICAL, s.vertical)
            putInt(KEY_QUALITY, s.quality)
            putFloat(KEY_RAIN, s.rain)
        }
    }

    fun frameDelayMs(quality: Int): Long = when (quality) {
        0 -> 50L      // 20 FPS / battery
        2 -> 17L      // ~60 FPS / ultra
        else -> 33L   // ~30 FPS / balanced
    }

    fun valueToProgress(value: Float, min: Float, max: Float): Int =
        (((value - min) / (max - min)) * 100f).roundToInt().coerceIn(0, 100)

    fun progressToValue(progress: Int, min: Float, max: Float): Float =
        min + (max - min) * (progress.coerceIn(0, 100) / 100f)
}
