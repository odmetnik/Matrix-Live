package hr.phoenixart.matrixwallpaper

import android.graphics.*
import kotlin.math.*

class MatrixRenderer {

    private data class LayerSpec(
        val gapDp: Float,
        val baseSpeed: Float,
        val alpha: Float,
        val fontDp: Float,
        val front: Boolean
    )
    private data class Column(var x: Float, var y: Float, var speed: Float, var len: Int, var seed: Float)
    private data class LayerState(val spec: LayerSpec, val cols: MutableList<Column> = mutableListOf())
    private data class Metrics(
        val rows: Int, val cols: Int, val step: Float,
        val lw: Float, val lh: Float, val x0: Float, val y0: Float,
        val cx: Float, val cy: Float
    )

    var settings: Prefs.Settings = Prefs.Settings()
        set(value) {
            val densityChanged = abs(field.density - value.density) > 0.02f
            field = value
            if (densityChanged && width > 1) resetLayers()
        }

    var offsetX: Float = 0f
    var offsetY: Float = 0f

    private var width = 1
    private var height = 1
    private var density = 1f
    private var startedAt = System.currentTimeMillis()

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.MONOSPACE
        textAlign = Paint.Align.CENTER
    }
    private val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val layers = listOf(
        LayerState(LayerSpec(23f, 64f, 0.30f, 10.5f, false)),
        LayerState(LayerSpec(29f, 92f, 0.50f, 14.0f, false)),
        LayerState(LayerSpec(55f, 146f, 0.75f, 18.0f, true))
    )

    private val glyphs = "ｦｱｳｴｵｶｷｹｺｻｼｽｾｿﾀﾂﾃﾅﾆﾇﾈﾊﾋﾎﾏﾐﾑﾒﾓﾔﾕﾗﾘﾜ0123456789Z:.=*+-<>|"

    private val logo = arrayOf(
        "0000000000000000000000000000000000000000000000000000000000000000",
        "0000000000000000000000000000000000000000000000000000000000000000",
        "0000000000000000000000000000000000000000000000000000000000000000",
        "0000000000000000000000010000000000000000000000000000000000000000",
        "0000000000000000000000110000000000000000000000000000000000000000",
        "0000000000000000000001100000000000000000000000000000000000000000",
        "0000000000000000001001100000000000000000000000000000000000000000",
        "0000000000000000011011100000000000000000000000000000000000000000",
        "0000000000000000011011100000000000000000000000000000000000000000",
        "0000000000000000111011100000000100000000000000000000000000000000",
        "0000000000000000111011100000000110000000000000000000000000000000",
        "0000000000000000111011110000000111000000000000000000000000000000",
        "0000000000000010111111110000000011110000000000000000000000000000",
        "0000000000000010111101110000000011111111100000000000000000000000",
        "0000000000000111011111111000000011111111111000000000000000000000",
        "0000000000000011011111111000000000111111111000000000000000000000",
        "0000000000000011101111111100000000111111111100000000000000000000",
        "0000000000000011110111111110000001111111111110000000000000000000",
        "0000000000000001111111111111000011111110000000000000000000000000",
        "0000000000000100111111111111100011111110000000000000000000000000",
        "0000000000000110011111111111110011111100000000000000000000000000",
        "0000000000000011101111111111111001110100000000000000000000000000",
        "0000000000000011111111111111101100111110000000000000000000000000",
        "0000000000000001111111111111110111011100000000000000000000000000",
        "0000000000000000011111111111111011101110000000000000000000000000",
        "0000000000000000100111111111101111101111000000000000000000000000",
        "0000000000000000111111111111110111110111100000000000000000000000",
        "0000000000000000011111111111111011111111100000000000000000000000",
        "0000000000000000000111111111111101111111110000000000000000000000",
        "0000000000000000000001111111111110111111110000000000000000000000",
        "0000000000000000000001111111111110111111110000000000000000000000",
        "0000000000000000000000111111111111111111100000000000000000000000",
        "0000000000000000000000001111111111011110000000001111110000000000",
        "0000000000000011111100000011111111011110000012222222222210000000",
        "0000000000012222222222210001111111011100001222222111001122000000",
        "0000000001222211000000122100000110111100022222210011222101200000",
        "0000000022221000000000000110000110111001222220000000001221110000",
        "0000000222200000000000000000000101110022222100000000000012210000",
        "0000001222000000000000000000001101100222220000000000000001220000",
        "0000002220000000000000000000010011002222100000000000000000221000",
        "0000012210000000000000000000000110122220000000000000000000022000",
        "0000012210000000000000000000001101222200000000000000000000022000",
        "0000022200000000000000000000110022222000000000000000000000022000",
        "0000022210000000000000000001100222210000000000000000000000022000",
        "0000012220000000000000000000012222100000000000000000000000122000",
        "0000002220000000000000000000222220022100000000000000000000221000",
        "0000001222000000000000000012222200022210000000000000000001220000",
        "0000000222210000000000001222221000001222100000000000000012210000",
        "0000000022222100000001222222200000000022220000000000000122100000",
        "0000000002222222222222222221000000000001222210000000012221000000",
        "0000000000022222222222222100000000000000012222222222222100000000",
        "0000000000000112222221100000000000000000000012222222210000000000",
        "0000000000000000000000000000000000000000000000000000000000000000",
        "0000000000000000000000000000000000000000000000000000000000000000"
    )

    fun resize(w: Int, h: Int, density: Float) {
        width = max(1, w)
        height = max(1, h)
        this.density = density.coerceAtLeast(0.75f)
        resetLayers()
    }

    fun render(canvas: Canvas, dt: Float, now: Long) {
        canvas.drawColor(Color.BLACK)
        val m = logoMetrics()
        // Relative time: epoch millis (~1.8e12) do not fit Float precision and froze the glyph animation.
        val t = (now - startedAt).coerceAtLeast(0L)
        drawLayer(canvas, layers[0], 0, dt, t, m)
        drawLayer(canvas, layers[1], 1, dt, t, m)
        drawLogoGlow(canvas, m)
        drawLogo(canvas, t, m)
        drawLayer(canvas, layers[2], 2, dt, t, m)
        drawVignette(canvas)
    }

    private fun resetLayers() {
        val d = settings.density.coerceIn(0.55f, 1.45f)
        layers.forEach { ls ->
            ls.cols.clear()
            val gap = ls.spec.gapDp * density / d
            val n = ceil(width / gap).toInt() + 8
            repeat(n) { i ->
                ls.cols += Column(
                    x = (i - 4) * gap,
                    y = Math.random().toFloat() * height,
                    speed = ls.spec.baseSpeed * density * (0.62f + Math.random().toFloat() * 0.78f),
                    len = 10 + (Math.random() * 18).toInt(),
                    seed = Math.random().toFloat() * 10000f
                )
            }
        }
    }

    private fun drawLayer(canvas: Canvas, ls: LayerState, li: Int, dt: Float, now: Long, m: Metrics) {
        val spec = ls.spec
        val z = (li + 1) / 3f
        val parallax = (li - 1) * offsetX * 34f * settings.depth
        textPaint.textSize = spec.fontDp * density
        val c = greenRgb()
        val gapScaledFont = spec.fontDp * density
        val rainGain = settings.rain.coerceIn(0.4f, 2.2f)
        val glyphStep = ((now / (125L + li * 55L)) % 100000L).toFloat() * 0.37f

        ls.cols.forEach { col ->
            col.y += col.speed * settings.speed * dt * (0.86f + li * 0.13f)
            val tail = col.len * gapScaledFont * 1.04f
            if (col.y - tail > height) {
                col.y = -Math.random().toFloat() * height * 0.30f
                col.speed = spec.baseSpeed * density * (0.62f + Math.random().toFloat() * 0.78f)
                col.len = 10 + (Math.random() * 18).toInt()
                col.seed = Math.random().toFloat() * 10000f
            }

            for (j in 0 until col.len) {
                val y = col.y - j * gapScaledFont * 1.04f
                if (y < -gapScaledFont || y > height + gapScaledFont) continue
                val x = col.x + parallax + sin(now * 0.00022 + col.seed).toFloat() * z * density
                var a = spec.alpha * (1f - j.toFloat() / col.len).pow(1.42f) * (0.72f + 0.28f * settings.depth)
                val protect = if (spec.front) 0.86f else if (li == 1) 0.73f else 0.57f
                a *= clarityAt(x, y, m, protect)
                if (spec.front) a *= 0.85f
                a = (a * rainGain).coerceIn(0f, 1f)

                val ch = glyph(col.seed + j + glyphStep)
                if (j == 0) {
                    a = min(1f, a * if (spec.front) 1.28f else 1.56f)
                    textPaint.color = Color.argb((a * 255).toInt(), 235, 255, 241)
                } else {
                    textPaint.color = Color.argb((a * 255).toInt(), c[0], c[1], c[2])
                }
                canvas.drawText(ch.toString(), x, y, textPaint)
            }
        }
    }

    private fun drawLogoGlow(canvas: Canvas, m: Metrics) {
        val c = greenRgb()
        val radius = m.lw * 0.41f
        val alpha = (0.13f * settings.glow).coerceAtMost(0.22f)
        paint.shader = RadialGradient(
            m.cx, m.cy, radius,
            intArrayOf(
                Color.argb((alpha * 255).toInt(), c[0], c[1], c[2]),
                Color.argb((alpha * 0.35f * 255).toInt(), c[0], c[1], c[2]),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.56f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(m.cx, m.cy, radius, paint)
        paint.shader = null
    }

    private fun drawLogo(canvas: Canvas, now: Long, m: Metrics) {
        if (settings.logo <= 0.01f) return
        val c = greenRgb()
        val tick = ((now / 170L) % 1000000L).toInt()
        val pulse = 1f + 0.022f * sin(now * 0.00185).toFloat()
        logoPaint.textSize = max(6f * density, m.step * 1.08f)
        logoPaint.clearShadowLayer()

        for (y in 0 until m.rows) {
            val row = logo[y]
            for (x in 0 until m.cols) {
                val v = row[x].code - '0'.code
                if (v <= 0) continue
                val ch = glyph((x * 31 + y * 97 + tick * 5).toFloat())
                val px = m.x0 + (x + .5f) * m.step
                val py = m.y0 + (y + .5f) * m.step
                val gold = v == 2
                val alpha = min(.99f, (if (gold) .86f else .94f) * settings.logo * pulse)

                if (gold) {
                    logoPaint.color = Color.argb((alpha * 255).toInt(), 255, 195, 58)
                    logoPaint.setShadowLayer(5f * density * settings.glow, 0f, 0f, Color.argb(150, 255, 178, 35))
                } else {
                    logoPaint.color = Color.argb((alpha * 255).toInt(), min(255, c[0] + 120), 255, min(255, c[2] + 120))
                    logoPaint.setShadowLayer(7f * density * settings.glow, 0f, 0f, Color.argb(170, c[0], c[1], c[2]))
                }
                canvas.drawText(ch.toString(), px, py, logoPaint)
            }
        }

        val labelY = m.y0 + m.lh + max(23f * density, m.step * 2.65f)
        labelPaint.textSize = max(11f * density, m.step * 1.80f)
        labelPaint.color = Color.argb(min(225, (settings.logo * .70f * 255).toInt()), 205, 255, 220)
        labelPaint.setShadowLayer(5f * density * settings.glow, 0f, 0f, Color.argb(100, c[0], c[1], c[2]))
        canvas.drawText("P H O E N I X   A R T", width / 2f + offsetX * 8f, labelY, labelPaint)
        labelPaint.clearShadowLayer()
        logoPaint.clearShadowLayer()
    }

    private fun drawVignette(canvas: Canvas) {
        val radius = max(width, height) * .78f
        paint.shader = RadialGradient(
            width / 2f, height / 2f, radius,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(118, 0, 0, 0)),
            floatArrayOf(0f, .70f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        paint.shader = null
    }

    private fun logoMetrics(): Metrics {
        val rows = logo.size
        val cols = logo[0].length

        // Tuned for tall displays such as Galaxy S24 Ultra (19.5:9), but remains adaptive.
        val maxW = min(width * .76f, 620f * density)
        val maxH = min(height * .34f, 620f * density)
        var step = min(maxW / cols, maxH / rows)
        step = max(4.4f * density, step)
        val lw = cols * step
        val lh = rows * step
        val shiftX = offsetX * 12f
        val centerY = height * (.49f + settings.vertical.coerceIn(-.16f, .16f))
        val shiftY = offsetY * 5f
        return Metrics(
            rows, cols, step, lw, lh,
            (width - lw) / 2f + shiftX,
            centerY - lh / 2f - shiftY,
            width / 2f + shiftX,
            centerY - shiftY
        )
    }

    private fun clarityAt(x: Float, y: Float, m: Metrics, strength: Float): Float {
        val q = max(abs(x - m.cx) / (m.lw * .62f), abs(y - m.cy) / (m.lh * .61f))
        if (q >= 1f) return 1f
        return ((1f - strength) + strength * q * q).coerceIn(.07f, 1f)
    }

    private fun greenRgb(): IntArray {
        val hsv = floatArrayOf(135f, 1f, 1f)
        hsv[0] = (hsv[0] + settings.tint.coerceIn(-.30f, .30f) * 80f + 360f) % 360f
        val c = Color.HSVToColor(hsv)
        return intArrayOf(Color.red(c), Color.green(c), Color.blue(c))
    }

    private fun random01(n: Float): Float {
        val x = sin(n * 12.9898f + 78.233f) * 43758.5453f
        return x - floor(x)
    }

    private fun glyph(seed: Float): Char {
        val i = floor(random01(seed) * glyphs.length).toInt().coerceIn(0, glyphs.length - 1)
        return glyphs[i]
    }

}
