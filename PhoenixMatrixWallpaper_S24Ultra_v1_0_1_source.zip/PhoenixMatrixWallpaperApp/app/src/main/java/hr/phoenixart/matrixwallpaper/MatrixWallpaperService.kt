package hr.phoenixart.matrixwallpaper

import android.content.SharedPreferences
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

class MatrixWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = MatrixEngine()

    inner class MatrixEngine : Engine(), SharedPreferences.OnSharedPreferenceChangeListener {
        private val handler = Handler(Looper.getMainLooper())
        private val renderer = MatrixRenderer()
        private val prefs by lazy { getSharedPreferences(Prefs.PREF_NAME, android.content.Context.MODE_PRIVATE) }
        private var visible = false
        private var lastTime = System.currentTimeMillis()
        private var widthPx = 1
        private var heightPx = 1

        private val drawRunner = Runnable { drawFrame() }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setOffsetNotificationsEnabled(true)
            prefs.registerOnSharedPreferenceChangeListener(this)
            renderer.settings = Prefs.load(this@MatrixWallpaperService)
        }

        override fun onDestroy() {
            handler.removeCallbacks(drawRunner)
            prefs.unregisterOnSharedPreferenceChangeListener(this)
            super.onDestroy()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            if (visible) {
                lastTime = System.currentTimeMillis()
                drawFrame()
            } else {
                handler.removeCallbacks(drawRunner)
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            widthPx = width.coerceAtLeast(1)
            heightPx = height.coerceAtLeast(1)
            renderer.resize(widthPx, heightPx, resources.displayMetrics.density)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            handler.removeCallbacks(drawRunner)
            super.onSurfaceDestroyed(holder)
        }

        override fun onOffsetsChanged(
            xOffset: Float,
            yOffset: Float,
            xOffsetStep: Float,
            yOffsetStep: Float,
            xPixelOffset: Int,
            yPixelOffset: Int
        ) {
            renderer.offsetX = (xOffset - .5f).coerceIn(-.5f, .5f)
            renderer.offsetY = (yOffset - .5f).coerceIn(-.5f, .5f)
        }

        override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
            renderer.settings = Prefs.load(this@MatrixWallpaperService)
        }

        private fun drawFrame() {
            handler.removeCallbacks(drawRunner)
            if (!visible || widthPx <= 1 || heightPx <= 1) return

            val now = System.currentTimeMillis()
            val dt = ((now - lastTime).coerceAtMost(50L) / 1000f).coerceAtLeast(0f)
            lastTime = now

            var canvas: Canvas? = null
            try {
                // GPU canvas: software lockCanvas() cannot keep up with ~1000 shadowed glyphs per frame.
                canvas = surfaceHolder.lockHardwareCanvas()
                if (canvas != null) renderer.render(canvas, dt, now)
            } catch (_: Throwable) {
                // Surface can disappear while One UI switches wallpaper preview/state.
            } finally {
                if (canvas != null) {
                    try { surfaceHolder.unlockCanvasAndPost(canvas) } catch (_: Throwable) {}
                }
            }

            handler.postDelayed(drawRunner, Prefs.frameDelayMs(renderer.settings.quality))
        }
    }
}
