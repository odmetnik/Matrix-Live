# Phoenix Matrix Wallpaper — Android Live Wallpaper

Native Android live-wallpaper verzija Phoenix Art Matrix Rain animacije.

## Završene funkcije

- pravi Android `WallpaperService` — nije video niti web stranica
- Canvas 2D renderer bez WebGL-a, CDN-a i internetske veze
- Phoenix znak sastavljen od Matrix znakova
- zlatni / amber infinity element
- tri dubinska sloja Matrix kiše
- zaštitna zona oko loga da ga prednji stupci ne pregaze
- diskretni glow i vignette
- parallax preko pomaka Android početnog zaslona
- adaptivno pozicioniranje za visoke zaslone, posebno Galaxy S24 Ultra
- renderer se zaustavlja kad wallpaper nije vidljiv
- Battery 20 FPS / Balanced 30 FPS / Ultra 60 FPS
- live preview u aplikaciji
- promjene postavki odmah se vide u previewu i aktivnom wallpaperu
- podešavanje brzine, dubine, Phoenix intenziteta, glowa, gustoće, vertikalnog položaja i zelene nijanse
- direktan gumb **Postavi kao live wallpaper**

## Preporučene postavke za Samsung Galaxy S24 Ultra

- Kvaliteta: **Balanced — 30 FPS** za svakodnevnu uporabu
- Brzina: **1.00×**
- Dubina: **1.00×**
- Phoenix: **1.25×**
- Sjaj: **1.15×**
- Gustoća: **1.00×**
- Vertikalni položaj: **0%**

Ultra 60 FPS izgleda glađe, ali troši više baterije. Wallpaper automatski prestaje crtati kad nije vidljiv.

## Android Studio

1. Otvori mapu `PhoenixMatrixWallpaperApp` u Android Studiju.
2. Dopusti Gradle sync i instalaciju Android SDK 34 ako se zatraži.
3. `Build > Build APK(s)` za debug APK.
4. Instaliraj APK na S24 Ultra.
5. Otvori aplikaciju, namjesti izgled i pritisni **Postavi kao live wallpaper**.

## Debug APK

Debug build je odmah instalabilan na telefonu:

`app/build/outputs/apk/debug/app-debug.apk`

## Signed release APK

Za finalni APK koji možeš trajno koristiti i nadograđivati istim potpisom:

1. U PowerShellu pokreni `GENERATE_RELEASE_KEY_WINDOWS.ps1`.
2. Sačuvaj `phoenix-release.jks` i lozinke. Nemoj izgubiti ključ.
3. Ako imaš Gradle 8.7 u PATH-u, pokreni `BUILD_SIGNED_RELEASE_WINDOWS.ps1`.
4. Rezultat je `app/build/outputs/apk/release/app-release.apk`.

Android Studio može napraviti isto kroz **Build > Generate Signed App Bundle or APK > APK**.

## GitHub Actions build

Projekt sadrži `.github/workflows/build-apk.yml`. Nakon pusha na GitHub, workflow može izgraditi debug i unsigned release APK bez lokalnog Android Studija. Debug APK je instalabilan; release APK treba potpisati vlastitim release ključem.

## Izmjene u v1.0.1 (pregled koda)

- Matrix kiša: popravljen Float gubitak preciznosti (svaki stupac je prikazivao jedan te isti znak, bez mutacije).
- Puls loga: isti uzrok, sada stvarno pulsira.
- Wallpaper engine: `lockHardwareCanvas()` umjesto softverskog `lockCanvas()`.
- Preview: ograničen na ~42% visine zaslona i crtan u pravom mjerilu, slideri su vidljivi uz njega.
- Tema: fiksno tamna (DayNight je u svijetlom načinu davao nečitljiv tekst na crnoj pozadini).

## Izmjene u v1.0.2

- Matrix kiša je 2,5x svjetlija i zasićenije zelena (slojevi 0.30 / 0.50 / 0.75 umjesto 0.12 / 0.20 / 0.31).
- Novi slider **Svjetlina koda** (0.40x do 2.20x).

## Napomena o ovom paketu

Izvorni kod i resursi su provjereni na razini strukture/XML-a i Kotlin sintakse. U trenutnom ChatGPT runtimeu nema Android SDK-a ni Gradle distribucije i nema mrežnog pristupa za njihovo preuzimanje, pa ovdje nije bilo moguće fizički izvršiti `assembleDebug` i isporučiti stvarno kompajlirani APK. Projekt je pripremljen upravo za taj završni Android build.
